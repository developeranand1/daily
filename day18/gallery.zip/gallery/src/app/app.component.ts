import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { LightboxModule } from 'ngx-lightbox';
import { Lightbox } from 'ngx-lightbox';
interface Image {
  src: string;
  thumb: string;
  hover?: boolean; // Define hover property as optional
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet,LightboxModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'gallery';
  images = [
    { src: 'assets/imgs/first.jpg', thumb: 'https://picsum.photos/300' },
    { src: 'assets/imgs/second.jpg', thumb: 'https://picsum.photos/300' },
    { src: 'assets/imgs/third.jpg', thumb: 'https://picsum.photos/300' }
  ];
  
  hoveredIndex: number | null = null;
  constructor(private lightbox: Lightbox) {}

  open(index: number): void {
    // Open the lightbox with the specified index
    this.lightbox.open(this.images, index);
  }


  openDialog(action: string, imageIndex: number): void {
    const imageSrc = this.images[imageIndex].src;
    switch (action) {
      case 'download':
        this.downloadImage(imageSrc);
        break;
      case 'share':
        this.shareImage(imageSrc);
        break;
      case 'rotate':
        this.rotateImage(imageSrc);
        break;
      default:
        break;
    }
  }
  
  
  downloadImage(imageSrc: string): void {
    const link = document.createElement('a');
    link.href = imageSrc;
    link.download = 'image.jpg';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
  
  shareImage(imageSrc: string): void {
    // Construct LinkedIn sharing URL with image source URL
    const linkedInShareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(imageSrc)}`;
    // Open LinkedIn sharing window
    window.open(linkedInShareUrl, '_blank');
  }

  
  rotateImage(imageSrc: string): void {
    const imageElement = document.querySelector(`img[src="${imageSrc}"]`) as HTMLImageElement;
    if (imageElement) {
      imageElement.style.transition = 'transform 0.5s ease-in-out';
      imageElement.style.transform += 'rotate(90deg)';
    }
  }
  
  setHoveredIndex(index: number): void {
    this.hoveredIndex = index;
  }

  clearHoveredIndex(): void {
    this.hoveredIndex = null;
  }

}
